using System;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.Bot.Builder.Azure;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.CognitiveServices.QnAMaker;
using Microsoft.Bot.Connector;

namespace Microsoft.Bot.Sample.QnABot
{
    [Serializable]
    public class RootDialog : IDialog<object>
    {
        //variable to verify that cutomer has accepted disclaimer before proceeding
        protected bool proceed = false;

        public async Task StartAsync(IDialogContext context)
        {
            /* Wait until the first message is received from the conversation and call MessageReceviedAsync 
            *  to process that message. */
            context.Wait(this.MessageReceivedAsync);
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            /* When MessageReceivedAsync is called, it's passed an IAwaitable<IMessageActivity>. To get the message,
            *  await the result. */
            var message = await result;
            
            //If customer has not accepted disclaimer yet
            if (!proceed)
            {
                //Set Welcome Note and Disclaimer
                var welcome = "Hello, \n Welcome to Pharma Bot! \n \n Please note that I am here to assist with general recommendations and my answers should not be used to try to auto-diagnose your health.\n \n If you have have personalized questions or concerns please visit us at the Pharmacy Pharma or go to the hospital in case of emergency.";
                
                //Display Welcome Note and Disclaimer for Customer
                await context.PostAsync(welcome);
                
                //Ask the Custmer to accept Disclaimer by calling function CustomerInfo
                PromptDialog.Confirm(
                        context,
                        CustomerInfo,
                        "Do you want to proceed?",
                        "Didn't get that!",
                        promptStyle: PromptStyle.Auto);
            }

            //capture the information that we entered from the QnA maker
            var qnaSubscriptionKey = Utils.GetAppSetting("QnASubscriptionKey");
            var qnaKBId = Utils.GetAppSetting("QnAKnowledgebaseId");

            //if proceed is true (Customer accepted the disclaimer)
            if (proceed)
            {
                //if Customer says bye during conversation
                if (message.Text == "Bye" || message.Text == "bye" || message.Text == "BYE")
                {
                    //set proceed to false so that customer goes through disclaimer again 
                    this.proceed = false;
                    
                    //respond by bye
                    await context.PostAsync("Hope i was able to answer your questions \n Good Bye!");
                }
                else
                {
                    // Validate if QnA Subscription Key and KnowledgeBase Id are not null
                    if (!string.IsNullOrEmpty(qnaSubscriptionKey) && !string.IsNullOrEmpty(qnaKBId))
                    {
                        await context.Forward(new BasicQnAMakerDialog(), AfterAnswerAsync, message, CancellationToken.None);
                    }
                    // if either the QnA Subscription Key or KnowledgeBase Id is not set
                    else
                    {
                        await context.PostAsync("Please set QnAKnowledgebaseId and QnASubscriptionKey in App Settings. Get them at https://qnamaker.ai.");
                    }
                }
            }
        }

        private async Task AfterAnswerAsync(IDialogContext context, IAwaitable<IMessageActivity> result)
        {
            // wait for the next user message
            context.Wait(MessageReceivedAsync);
        }

        //Validates if customer has accepted disclaimer
        public async Task CustomerInfo(IDialogContext context, IAwaitable<bool> argument)
        {
            //capture the customer's answer to the disclaimer
            var confirm = await argument;
            
            //If answer is YES
            if (confirm)
            {
                //modify the boolean variable proceed to true
                this.proceed = true;
                //Ask the customer what he would like to know about the COLD
                await context.PostAsync("Great!\n What would you like to learn about the common COLD or FLU today?");
            }
            //If answer is NO
            else
            {
                //say Bye to the customer
                await context.PostAsync("Sorry i could not help you today :( \n Good Bye.\n See you next time!");
            }
            // wait for the next user message
            context.Wait(MessageReceivedAsync);
        }

    }

    // For more information about this template visit http://aka.ms/azurebots-csharp-qnamaker
    [Serializable]
    public class BasicQnAMakerDialog : QnAMakerDialog
    {
        // Go to https://qnamaker.ai and feed data, train & publish your QnA Knowledgebase.        
        // Parameters to QnAMakerService are:
        // Required: subscriptionKey, knowledgebaseId, 
        // Optional: defaultMessage, scoreThreshold[Range 0.0 – 1.0]
        public BasicQnAMakerDialog() : base(new QnAMakerService(new QnAMakerAttribute(Utils.GetAppSetting("QnASubscriptionKey"), Utils.GetAppSetting("QnAKnowledgebaseId"), "Sorry I don't have an answer for your question today. \n Please call us or visit us at the Pharmacy and one of my human colleagues will be happy to answer your question.", 0.5)))
        { }
    }
}